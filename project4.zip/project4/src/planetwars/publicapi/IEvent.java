package planetwars.publicapi;

public interface IEvent {
}
