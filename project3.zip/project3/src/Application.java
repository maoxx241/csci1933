
/*Name:Qi Mao(Student ID:5306940) and Haowen Luo(Student ID:5281069)
username: maoxx241 and luoxx560
Course:CSCI 1933*/
//The memory is 5M for SparseIntMatrix implementation because there are 5 DATA Field. N^2
//N^2-m=1000000^2-5*1000000=9995000000.

// We tried to use doubly linked list structure.

import java.util.Scanner;

public class Application {
    public static void main(String[] args) {
        Scanner c= new Scanner(System.in);

        System.out.println("Please enter which graph you want to see:");
        int i= c.nextInt();
        if(i==1){
            System.out.println("Please wait for 1 min");
            matrix1();

        }
        else if(i==2) {
            System.out.println("Please wait about 3 mins");
            matrix2();

        }

    }
    public static void matrix1(){
        SparseIntMatrix mat = new SparseIntMatrix(1000, 1000, "J:\\project\\project3\\src\\matrix1_data.txt");
        MatrixViewer.show(mat);
    }
    public static void matrix2(){
        SparseIntMatrix mat = new SparseIntMatrix(1000, 1000, "J:\\project\\project3\\src\\matrix2_data.txt");
        SparseIntMatrix mat1 = new SparseIntMatrix(1000, 1000, "J:\\project\\project3\\src\\matrix2_noise.txt");
        mat.minus(mat1);
        MatrixViewer.show(mat);
    }

}
