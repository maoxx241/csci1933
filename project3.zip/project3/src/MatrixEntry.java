public class MatrixEntry {
    private int Column;
    private int Row;
    private int Data;
    private MatrixEntry NextColumn;
    private MatrixEntry NextRow;
    private MatrixEntry PreviousColumn;
    private MatrixEntry PreviousRow;
    public MatrixEntry(int row, int col, int data){
        Column=col;
        Row=row;
        Data=data;

    }

    public int getColumn() {
        return Column;
    }

    public int getData() {
        return Data;
    }

    public int getRow() {
        return Row;
    }

    public void setColumn(int column) {
        Column = column;
    }

    public void setData(int data) {
        Data = data;
    }

    public void setRow(int row) {
        Row = row;
    }

    public MatrixEntry getNextRow() {
        return NextRow;
    }

    public MatrixEntry getNextColumn() {
        return NextColumn;
    }

    public void setNextColumn(MatrixEntry nextColumn) {
        NextColumn = nextColumn;
    }

    public void setNextRow(MatrixEntry nextRow) {
        NextRow = nextRow;
    }

    public MatrixEntry getPreviousColumn() {
        return PreviousColumn;
    }

    public MatrixEntry getPreviousRow() {
        return PreviousRow;
    }

    public void setPreviousColumn(MatrixEntry previousColumn) {
        PreviousColumn = previousColumn;
    }

    public void setPreviousRow(MatrixEntry previousRow) {
        PreviousRow = previousRow;
    }
}
