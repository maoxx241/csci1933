import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class SparseIntMatrix {
    private int NumCols;
    private int NumRows;
    private MatrixEntry[] MatrixArray=new MatrixEntry[0];
    private MatrixEntry[] colMatrix=new MatrixEntry[0];
    private MatrixEntry[] rowMatrix=new MatrixEntry[0];

    public SparseIntMatrix(int numRows, int numCols){
        NumCols=numCols;
        NumRows=numRows;
    }
/*This method is for building a linked list structure and link all data we get from the txt document.
* */
    public SparseIntMatrix(int numRows, int numCols, String inputFile){
        NumCols=numCols;
        NumRows=numRows;
        Scanner fileInput = null;
        File input=new File(inputFile);
        String[] array= new String[1];
        try {
            fileInput = new Scanner(input);
            while (fileInput.hasNext()) {

                if(array[array.length-1]!=null){
                    String[] temp=new String[1+array.length];
                    int ind;
                    for(ind=0;ind<array.length;ind++){
                        temp[ind]=array[ind];
                    }
                    array=temp;
                }
                array[array.length-1]= fileInput.nextLine();

            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        MatrixArray=new MatrixEntry[array.length];
        for(int i=0;i<array.length;i++){
            String[] parts = array[i].split(",");
            MatrixEntry Matrix=new MatrixEntry(Integer.parseInt(parts[0]),Integer.parseInt(parts[1]),Integer.parseInt(parts[2]));
            MatrixArray[i]=Matrix;
        }


        for(int i=1;i<MatrixArray.length;i++){
            MatrixEntry newMatrix = new MatrixEntry(MatrixArray[i].getRow(), MatrixArray[i].getColumn(), MatrixArray[i].getData());
            for (int j=0;j<colMatrix.length;j++){
                if(colMatrix[j].getColumn()==newMatrix.getColumn()){
                    if(colMatrix[j].getRow()>newMatrix.getRow()){
                        MatrixEntry temp=colMatrix[j];
                        while (temp.getPreviousRow()!=null){
                            if(temp.getPreviousRow()==null){
                                if(temp.getRow()>newMatrix.getRow()){
                                    temp.setPreviousRow(newMatrix);
                                    newMatrix.setNextRow(temp);
                                    //colMatrix[j]=newMatrix;

                                }
                            }else{
                                if(temp.getPreviousRow().getRow()>newMatrix.getRow()){
                                    temp=temp.getPreviousRow();
                                }else{
                                    MatrixEntry m=temp.getPreviousRow();
                                    temp.getPreviousRow().setNextRow(newMatrix);
                                    newMatrix.setNextRow(temp);
                                    temp.setPreviousRow(newMatrix);
                                    newMatrix.setPreviousRow(m);

                                }
                            }
                        }
                    }else{

                        MatrixEntry temp=colMatrix[j];
                        while (temp.getNextRow()!=null){
                            if(temp.getNextRow()==null){
                                if(temp.getRow()<newMatrix.getRow()){
                                    temp.setNextRow(newMatrix);
                                    newMatrix.setPreviousRow(temp);

                                }
                            }else{
                                if(temp.getNextRow().getRow()<newMatrix.getRow()){
                                    temp=temp.getNextRow();
                                }else{
                                    MatrixEntry m=temp.getNextRow();
                                    temp.getNextRow().setPreviousRow(newMatrix);
                                    newMatrix.setPreviousRow(temp);
                                    temp.setNextRow(newMatrix);
                                    newMatrix.setNextRow(m);

                                }
                            }
                        }
                    }
                }
            }

            for(int j=0;j<rowMatrix.length;j++){
                if(rowMatrix[j].getRow()==newMatrix.getRow()){
                    if(rowMatrix[j].getColumn()>newMatrix.getColumn()){
                        MatrixEntry temp=rowMatrix[j];
                        while (temp.getPreviousColumn()!=null){
                            if(temp.getPreviousColumn()==null){
                                if(temp.getColumn()>newMatrix.getColumn()){
                                    temp.setPreviousColumn(newMatrix);
                                    newMatrix.setNextColumn(temp);

                                }
                            }else{
                                if(temp.getPreviousColumn().getColumn()>newMatrix.getColumn()){
                                    temp=temp.getPreviousColumn();
                                }else{
                                    MatrixEntry m=temp.getPreviousColumn();
                                    temp.getPreviousColumn().setNextColumn(newMatrix);
                                    newMatrix.setNextColumn(temp);
                                    temp.setPreviousColumn(newMatrix);
                                    newMatrix.setNextColumn(m);

                                }
                            }
                        }
                    }else{

                        MatrixEntry temp=rowMatrix[j];
                        while (temp.getNextColumn()!=null){
                            if(temp.getNextColumn()==null){
                                if(temp.getColumn()<newMatrix.getColumn()){
                                    temp.setNextColumn(newMatrix);
                                    newMatrix.setPreviousColumn(temp);

                                }
                            }else{
                                if(temp.getNextColumn().getColumn()<newMatrix.getColumn()){
                                    temp=temp.getNextColumn();
                                }else{
                                    MatrixEntry m=temp.getNextColumn();
                                    temp.getNextColumn().setPreviousColumn(newMatrix);
                                    newMatrix.setPreviousColumn(temp);
                                    temp.setNextColumn(newMatrix);
                                    newMatrix.setNextColumn(m);

                                }
                            }
                        }
                    }
                }
            }
        }




    }
    public int getNumCols() {
        return NumCols;
    }

    public int getNumRows() {
        return NumRows;
    }

    public MatrixEntry[] getMatrixArray() {
        return MatrixArray;
    }

    public int getElement(int row, int col){
        int result=0;
        int r=0,c=0;
        if(0<=row&&0<=col&&row<this.NumRows&&col<this.NumCols) {
            for (int i = 0; i < MatrixArray.length; i++) {
                r = MatrixArray[i].getRow();
                c = MatrixArray[i].getColumn();
                if(r==row&&c==col){
                    result=MatrixArray[i].getData();
                }


            }
        }
        return result;
    }

    public Boolean setElement(int row,int col,int data){
        Boolean result=false;
        int r=0,c=0;
        if(0<=row&&0<=col&&row<this.NumRows&&col<this.NumCols) {
           Boolean Result=true;
            for (int i = 0; i < MatrixArray.length; i++) {
                r = MatrixArray[i].getRow();
                c = MatrixArray[i].getColumn();
                if(r==row&&c==col){
                   Result=false;
                   MatrixArray[i].setData(data);
                   result=true;
                }
            }

            if(Result){
                MatrixEntry[] temp=new MatrixEntry[MatrixArray.length+1];
                for(int i=0;i<MatrixArray.length;i++){
                    temp[i]=MatrixArray[i];
                }
                MatrixArray=temp;
                MatrixArray[MatrixArray.length-1]=new MatrixEntry(row, col, data);
                result=true;
            }

        }
        return result;

    }
    //
    public void set(int row,int col){
        int r=0,c=0;
        if(0<=row&&0<=col&&row<this.NumRows&&col<this.NumCols) {
            Boolean Result=false;
            for (int i = 0; i < MatrixArray.length; i++) {
                r = MatrixArray[i].getRow();
                c = MatrixArray[i].getColumn();
                if(r==row&&c==col){
                    Result=true;
                    break;
                }
            }

            if(!Result){
                MatrixEntry[] temp=new MatrixEntry[MatrixArray.length+1];
                for(int i=0;i<MatrixArray.length;i++){
                    temp[i]=MatrixArray[i];
                }
                MatrixArray=temp;
                MatrixArray[MatrixArray.length-1]=new MatrixEntry(row, col, 0);
            }

        }

    }




    public boolean minus(SparseIntMatrix otherMat){
        boolean result = false;
        MatrixEntry[] otherMatrixArray=otherMat.getMatrixArray();
        if(this.NumCols==otherMat.getNumCols()&&this.NumRows==otherMat.getNumRows()) {
            result = true;
            for(int i=0;i<otherMatrixArray.length;i++){
                int col=otherMatrixArray[i].getColumn();
                int row=otherMatrixArray[i].getRow();
                this.set(row,col);


            }

            for(int i=0;i<this.MatrixArray.length;i++){
                int r = this.MatrixArray[i].getRow();
                int c = this.MatrixArray[i].getColumn();
                for(int j=0;j<otherMatrixArray.length;j++){
                    int col=otherMatrixArray[j].getColumn();
                    int row=otherMatrixArray[j].getRow();
                    if(c==col&&r==row){
                        MatrixArray[i].setData(MatrixArray[i].getData()-otherMatrixArray[j].getData());
                    }

                }
            }



        }
        return result;
    }

    public boolean plus(SparseIntMatrix otherMat){
        boolean result = false;
        MatrixEntry[] otherMatrixArray=otherMat.getMatrixArray();
        if(this.NumCols==otherMat.getNumCols()&&this.NumRows==otherMat.getNumRows()) {
            result = true;
            for(int i=0;i<otherMatrixArray.length;i++){
                int col=otherMatrixArray[i].getColumn();
                int row=otherMatrixArray[i].getRow();
                this.set(row,col);
                /*boolean Result=true;
                for(int j=0;j<this.MatrixArray.length;j++){
                    int r = this.MatrixArray[j].getRow();
                    int c = this.MatrixArray[j].getColumn();
                    if(r==row&&c==col){
                        Result=false;
                        break;
                    }
                }

                if(Result){
                    MatrixEntry[] temp=new MatrixEntry[MatrixArray.length+1];
                    for(int k=0;k<MatrixArray.length;k++){
                        temp[k]=MatrixArray[k];
                    }
                    MatrixArray=temp;
                    MatrixArray[MatrixArray.length-1]=new MatrixEntry(row, col, 0);
                }*/

            }

            for(int i=0;i<this.MatrixArray.length;i++){
                int r = this.MatrixArray[i].getRow();
                int c = this.MatrixArray[i].getColumn();
                for(int j=0;j<otherMatrixArray.length;j++){
                    int col=otherMatrixArray[j].getColumn();
                    int row=otherMatrixArray[j].getRow();
                    if(c==col&&r==row){
                        MatrixArray[i].setData(MatrixArray[i].getData()+otherMatrixArray[j].getData());
                    }

                }
            }



        }
        return result;
    }






}
